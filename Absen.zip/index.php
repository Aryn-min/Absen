<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

date_default_timezone_set('Asia/Jakarta');

// ==========================================
// 1. ROLLING TOKEN DINAMIS 30 DETIK
// ==========================================
$secret_key      = "STIKES_DONA_PKKMB_2026_SECURE_KEY";
$time_window     = floor(time() / 30); // Berputar tiap 30 detik

$current_token   = substr(hash('sha256', $time_window . $secret_key), 0, 16);
$prev_token      = substr(hash('sha256', ($time_window - 1) . $secret_key), 0, 16); // Toleransi jeda loading

// ==========================================
// 2. KONEKSI DATABASE
// ==========================================
$db_host = "sql304.infinityfree.com";
$db_user = "if0_41262517";     
$db_pass = "ma7cUlvhfjtZJN";         
$db_name = "if0_41262517_4bsenn";

// ==========================================
// 3. VALIDASI TOKEN DINAMIS
// ==========================================
$token_request = isset($_GET['token']) ? trim($_GET['token']) : (isset($_POST['token']) ? trim($_POST['token']) : '');

$is_token_valid = ($token_request === $current_token || $token_request === $prev_token);

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !$is_token_valid) {
    http_response_code(403);
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Akses Ditolak - Wajib Scan QR</title>
      <script src="https://cdn.tailwindcss.com"></script>
      <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
      <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
    </head>
    <body class="bg-slate-950 text-white min-h-screen flex items-center justify-center p-6 text-center select-none">
      <div class="max-w-sm bg-slate-900 border border-slate-800 p-8 rounded-3xl shadow-2xl space-y-5">
        <div class="w-16 h-16 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-2xl flex items-center justify-center mx-auto text-2xl font-bold">
          🔒
        </div>
        <div>
          <h1 class="text-lg font-bold text-white">Akses QR Tidak Valid / Kedaluwarsa</h1>
          <p class="text-xs text-slate-400 leading-relaxed mt-1.5">
            Tautan tidak valid atau masa berlaku telah habis. Silakan lakukan <strong>Scan Kode QR Resmi</strong> terbaru di layar panitia.
          </p>
        </div>

        <div class="bg-rose-950/40 border border-rose-500/30 p-3 rounded-2xl">
          <p class="text-xs text-rose-300">Halaman akan ditutup otomatis dalam:</p>
          <p id="countdownText" class="text-xl font-mono font-extrabold text-rose-400 mt-1">30 Detik</p>
        </div>
      </div>

      <script>
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('copy', e => e.preventDefault());

        let timeLeft = 30;
        const countDisplay = document.getElementById('countdownText');

        const countdownTimer = setInterval(() => {
          timeLeft--;
          if (timeLeft > 0) {
            countDisplay.innerText = `${timeLeft} Detik`;
          } else {
            clearInterval(countdownTimer);
            countDisplay.innerText = "0 Detik";
            try { sessionStorage.clear(); localStorage.clear(); } catch(e){}
            window.open('', '_self', ''); 
            window.close();
            setTimeout(() => { window.location.replace('about:blank'); }, 100);
          }
        }, 1000);
      </script>
    </body>
    </html>
    <?php
    exit;
}

// ==========================================
// 4. ENDPOINT AJAX CEK GUGUS
// ==========================================
if (isset($_GET['action']) && $_GET['action'] === 'cek_gugus') {
    header('Content-Type: application/json; charset=utf-8');
    $nama = isset($_GET['nama']) ? trim($_GET['nama']) : '';

    if (!empty($nama)) {
        $conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);
        if (!$conn->connect_error) {
            $stmt = $conn->prepare("SELECT gugus_kelompok FROM presensi_pkkmb WHERE LOWER(TRIM(nama_lengkap)) = LOWER(?) ORDER BY id ASC LIMIT 1");
            if ($stmt) {
                $stmt->bind_param("s", $nama);
                $stmt->execute();
                $res = $stmt->get_result();
                if ($row = $res->fetch_assoc()) {
                    echo json_encode(["status" => "found", "gugus" => $row['gugus_kelompok']]);
                    $stmt->close();
                    $conn->close();
                    exit;
                }
                $stmt->close();
            }
            $conn->close();
        }
    }
    echo json_encode(["status" => "not_found"]);
    exit;
}

// ==========================================
// 5. PROSES SIMPAN DATA (POST)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    mysqli_report(MYSQLI_REPORT_OFF);

    // Validasi token saat submit form
    if (!$is_token_valid) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Token absensi telah kedaluwarsa. Silakan scan ulang kode QR."]);
        exit;
    }

    $conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Koneksi database gagal: " . $conn->connect_error]);
        exit;
    }
    $conn->query("SET time_zone = '+07:00'");

    $nama  = isset($_POST['nama']) ? trim($_POST['nama']) : '';
    $gugus = isset($_POST['gugus']) ? trim($_POST['gugus']) : '';
    $hari  = isset($_POST['hari']) ? trim($_POST['hari']) : '';

    if (empty($nama) || empty($hari)) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Harap mengisi data diri secara lengkap."]);
        $conn->close();
        exit;
    }

    $waktu_sekarang = date('Y-m-d H:i:s');

    // Cek Kehadiran Pembekalan
    $stmt_pembekalan = $conn->prepare("SELECT id FROM presensi_pembekalan WHERE LOWER(TRIM(nama_lengkap)) = LOWER(?) LIMIT 1");
    if ($stmt_pembekalan) {
        $stmt_pembekalan->bind_param("s", $nama);
        $stmt_pembekalan->execute();
        $stmt_pembekalan->store_result();

        if ($stmt_pembekalan->num_rows === 0) {
            $stmt_log = $conn->prepare("INSERT INTO presensi_pelanggaran (nama_lengkap, gugus_kelompok, hari_kehadiran, keterangan, waktu_percobaan) VALUES (?, ?, ?, 'Mencoba absen PKKMB tanpa mengikuti pembekalan', ?)");
            if ($stmt_log) {
                $stmt_log->bind_param("ssss", $nama, $gugus, $hari, $waktu_sekarang);
                $stmt_log->execute();
                $stmt_log->close();
            }

            http_response_code(400);
            echo json_encode([
                "status"  => "error", 
                "message" => "Nama \"" . htmlspecialchars($nama) . "\" belum terdaftar pada Absensi Pembekalan. Silakan hubungi panitia."
            ]);
            $stmt_pembekalan->close();
            $conn->close();
            exit;
        }
        $stmt_pembekalan->close();
    }

    // Kunci Gugus Sesuai Hari Ke-1
    $gugus_check = $conn->prepare("SELECT gugus_kelompok FROM presensi_pkkmb WHERE LOWER(TRIM(nama_lengkap)) = LOWER(?) ORDER BY id ASC LIMIT 1");
    if ($gugus_check) {
        $gugus_check->bind_param("s", $nama);
        $gugus_check->execute();
        $res_gugus = $gugus_check->get_result();

        if ($row_gugus = $res_gugus->fetch_assoc()) {
            $gugus = $row_gugus['gugus_kelompok'];
        }
        $gugus_check->close();
    }

    if (empty($gugus)) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Harap memilih Gugus / Kelompok."]);
        $conn->close();
        exit;
    }

    // Cek Absen Ganda
    $check_stmt = $conn->prepare("SELECT id FROM presensi_pkkmb WHERE LOWER(TRIM(nama_lengkap)) = LOWER(?) AND hari_kehadiran = ? LIMIT 1");
    if ($check_stmt) {
        $check_stmt->bind_param("ss", $nama, $hari);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            http_response_code(400);
            echo json_encode([
                "status"  => "error", 
                "message" => "Nama \"" . htmlspecialchars($nama) . "\" sudah tercatat hadir pada " . $hari . "."
            ]);
            $check_stmt->close();
            $conn->close();
            exit;
        }
        $check_stmt->close();
    }

    $query_id = $conn->query("SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM presensi_pkkmb");
    $row_id   = $query_id->fetch_assoc();
    $next_id  = (int)$row_id['next_id'];

    $stmt = $conn->prepare("INSERT INTO presensi_pkkmb (id, nama_lengkap, gugus_kelompok, hari_kehadiran, waktu_absen) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Query gagal disiapkan: " . $conn->error]);
        $conn->close();
        exit;
    }

    $stmt->bind_param("issss", $next_id, $nama, $gugus, $hari, $waktu_sekarang);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Presensi PKKMB berhasil disimpan dengan No. Urut " . $next_id]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Gagal menyimpan data: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>
<!DOCTYPE html>
<html lang="id" class="select-none">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <title>Kehadiran Peserta PKKMB 2026</title>
  
  <link rel="icon" type="image/jpeg" href="logodona.jpg">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { 
      font-family: 'Plus Jakarta Sans', sans-serif; 
      -webkit-touch-callout: none;
      -webkit-user-select: none;
      user-select: none;
    }
  </style>
</head>
<body class="bg-cover bg-center bg-no-repeat bg-fixed min-h-screen flex items-center justify-center p-4 relative" style="background-image: url('bgweb.jpeg');">

  <div class="absolute inset-0 bg-slate-900/40 backdrop-blur-[2px]"></div>

  <div class="w-full max-w-md bg-white/95 backdrop-blur-md border border-white/20 rounded-3xl p-6 shadow-2xl relative z-10 overflow-hidden">
    
    <div class="text-center mb-6">
      <div class="flex justify-center mb-3">
        <img src="logodona.jpg" alt="Logo STIKes Dona Palembang" class="h-20 w-auto object-contain" onerror="this.style.display='none'">
      </div>
      <h1 class="text-2xl font-bold tracking-tight text-slate-900">Absen PKKMB STIKes Dona Palembang</h1>
      <p class="text-xs text-slate-500 mt-1">Masukkan data diri untuk mencatat kehadiran</p>
    </div>

    <form id="absenForm" onsubmit="handleSubmit(event)" class="space-y-4" autocomplete="off">
      <input type="hidden" name="token" value="<?= htmlspecialchars($token_request) ?>">
      
      <div>
        <label for="nama" class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Nama Lengkap</label>
        <input 
          type="text" 
          id="nama" 
          name="nama" 
          required 
          autocomplete="off"
          placeholder="Masukkan nama sesuai pembekalan..." 
          oninvalid="this.setCustomValidity('Harap di isi dengan lengkap')"
          oninput="handleNameInput(this)"
          class="w-full px-4 py-3 bg-slate-50 border border-slate-300 focus:border-slate-800 focus:bg-white focus:ring-1 focus:ring-slate-800 rounded-xl text-sm text-slate-900 placeholder-slate-400 outline-none transition-all select-text"
        >
      </div>

      <div>
        <div class="flex justify-between items-center mb-1.5">
          <label for="gugus" class="block text-xs font-bold uppercase tracking-wider text-slate-600">Gugus / Kelompok</label>
          <span id="gugusBadge" class="hidden text-[10px] bg-emerald-100 text-emerald-700 font-semibold px-2 py-0.5 rounded-full border border-emerald-300">
            🔒 Terkunci dari Hari Ke-1
          </span>
        </div>
        <select 
          id="gugus" 
          name="gugus" 
          required 
          oninvalid="this.setCustomValidity('Harap di isi dengan lengkap')"
          oninput="this.setCustomValidity('')"
          class="w-full px-4 py-3 bg-slate-50 border border-slate-300 focus:border-slate-800 focus:bg-white focus:ring-1 focus:ring-slate-800 rounded-xl text-sm text-slate-900 outline-none transition-all"
        >
          <option value="" disabled selected>-- Pilih Gugus / Kelompok --</option>
          <?php for($i=1; $i<=10; $i++): ?>
            <option value="Gugus / Kelompok <?= $i ?>">Gugus / Kelompok <?= $i ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div>
        <label for="hari" class="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Presensi Kehadiran</label>
        <select 
          id="hari" 
          name="hari" 
          required 
          oninvalid="this.setCustomValidity('Harap di isi dengan lengkap')"
          oninput="this.setCustomValidity('')"
          class="w-full px-4 py-3 bg-slate-50 border border-slate-300 focus:border-slate-800 focus:bg-white focus:ring-1 focus:ring-slate-800 rounded-xl text-sm text-slate-900 outline-none transition-all"
        >
          <option value="" disabled selected>-- Pilih Hari Kehadiran --</option>
          <option value="Hari Ke-1">Hari Ke-1</option>
          <option value="Hari Ke-2">Hari Ke-2</option>
          <option value="Hari Ke-3">Hari Ke-3</option>
        </select>
      </div>

      <button type="submit" id="submitBtn" class="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-xl shadow-md active:scale-[0.98] transition-all duration-200 mt-2">
        Kirim Presensi PKKMB
      </button>
    </form>

    <div id="alreadySubmittedMessage" class="hidden text-center py-8 space-y-3">
      <div class="inline-flex items-center justify-center w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full border border-emerald-200 mb-1">
        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path></svg>
      </div>
      <h2 class="text-xl font-bold text-slate-900">Absen Telah Tercatat, Terimakasih</h2>
      <p class="text-xs text-slate-500 max-w-xs mx-auto">Terimakasih Sudah Bergabung Bersama STIKes Dona Palembang Mahasiswa baru Semangat Ya.</p>
      <div class="flex justify-center items-center mt-4">
        <button type="button" onclick="resetView()" class="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-all border border-slate-300 shadow-sm active:scale-95">
          Isi Absen Lagi
        </button>
      </div>
    </div>

  </div>

  <script>
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('copy', e => e.preventDefault());

    if (window.history && window.history.replaceState) {
      window.history.replaceState(null, document.title, window.location.pathname);
    }

    const INACTIVITY_TIME = 30 * 1000;
    let lastActiveTime = Date.now();
    let inactivityTimer = null;

    function resetInactivityTimer() {
      lastActiveTime = Date.now();
      clearTimeout(inactivityTimer);
      inactivityTimer = setTimeout(forceCloseOrBlank, INACTIVITY_TIME);
    }

    function forceCloseOrBlank() {
      try { sessionStorage.clear(); localStorage.clear(); } catch (e) {}
      window.open('', '_self', ''); 
      window.close();
      setTimeout(() => { window.location.replace('about:blank'); }, 100);
    }

    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'input'].forEach(evt => {
      window.addEventListener(evt, resetInactivityTimer, { passive: true });
    });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        const timePassed = Date.now() - lastActiveTime;
        if (timePassed >= INACTIVITY_TIME) {
          forceCloseOrBlank();
        } else {
          resetInactivityTimer();
        }
      }
    });

    resetInactivityTimer();

    let debounceTimer;
    function handleNameInput(inputElem) {
      inputElem.setCustomValidity('');
      const nama = inputElem.value.trim();
      const selectGugus = document.getElementById('gugus');
      const badge = document.getElementById('gugusBadge');

      clearTimeout(debounceTimer);
      if (nama.length < 3) {
        unlockGugusField(selectGugus, badge);
        return;
      }

      debounceTimer = setTimeout(async () => {
        try {
          const res = await fetch(`index.php?action=cek_gugus&nama=${encodeURIComponent(nama)}`);
          const data = await res.json();

          if (data.status === 'found') {
            selectGugus.value = data.gugus;
            lockGugusField(selectGugus, badge);
          } else {
            unlockGugusField(selectGugus, badge);
          }
        } catch (err) {}
      }, 350);
    }

    function lockGugusField(selectElem, badgeElem) {
      selectElem.classList.add('bg-slate-200', 'text-slate-500', 'cursor-not-allowed', 'pointer-events-none');
      selectElem.classList.remove('bg-slate-50', 'text-slate-900');
      selectElem.setAttribute('tabindex', '-1');
      badgeElem.classList.remove('hidden');
    }

    function unlockGugusField(selectElem, badgeElem) {
      selectElem.classList.remove('bg-slate-200', 'text-slate-500', 'cursor-not-allowed', 'pointer-events-none');
      selectElem.classList.add('bg-slate-50', 'text-slate-900');
      selectElem.removeAttribute('tabindex');
      badgeElem.classList.add('hidden');
    }

    async function handleSubmit(e) {
      e.preventDefault();
      const submitBtn = document.getElementById('submitBtn');
      const form = document.getElementById('absenForm');
      const formData = new FormData(form);

      submitBtn.disabled = true;
      submitBtn.innerText = 'Memverifikasi...';

      try {
        const response = await fetch('./', { method: 'POST', body: formData });
        const result = await response.json();

        if (response.ok && result.status === 'success') {
          document.getElementById('absenForm').classList.add('hidden');
          document.getElementById('alreadySubmittedMessage').classList.remove('hidden');
        } else {
          alert(result.message || 'Terjadi kesalahan saat menyimpan absensi.');
        }
      } catch (err) {
        alert('Gagal terhubung ke server. Silakan coba lagi.');
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerText = 'Kirim Presensi PKKMB';
      }
    }

    function resetView() {
      const selectGugus = document.getElementById('gugus');
      const badge = document.getElementById('gugusBadge');

      document.getElementById('absenForm').reset();
      unlockGugusField(selectGugus, badge);
      document.getElementById('absenForm').classList.remove('hidden');
      document.getElementById('alreadySubmittedMessage').classList.add('hidden');
      resetInactivityTimer();
    }
  </script>
</body>
</html>
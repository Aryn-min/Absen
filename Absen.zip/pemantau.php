<?php
// ==========================================
// 1. PENGATURAN CACHE CONTROL & TOKEN DINAMIS
// ==========================================
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

date_default_timezone_set('Asia/Jakarta');

$url_secret_key    = "hayo gataupwya"; // Kunci URL (?key=hayo gataupwya)
$form_pin_password = "sekretaris44";   // Kata Sandi Form
$cookie_name       = "auth_pemantau_2026";
$cookie_token      = hash('sha256', "stikes_dona_secure_auth_token");

$secret_token_qr   = "STIKES_DONA_PKKMB_2026_SECURE_KEY";

// ==========================================
// 2. KONEKSI DATABASE
// ==========================================
$db_host = "sql304.infinityfree.com";
$db_user = "if0_41262517";     
$db_pass = "ma7cUlvhfjtZJN";         
$db_name = "if0_41262517_4bsenn";

// ==========================================
// 3. PROSES AUTENTIKASI (LOGIN & LOGOUT)
// ==========================================
$login_error = "";

// A. Jika masuk lewat link URL rahasia (?key=...)
if (isset($_GET['key']) && $_GET['key'] === $url_secret_key) {
    setcookie($cookie_name, $cookie_token, time() + (86400 * 7), "/");
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}

// B. Jika login lewat Form Kunci Layar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pin_akses'])) {
    if ($_POST['pin_akses'] === $form_pin_password || $_POST['pin_akses'] === $url_secret_key) {
        setcookie($cookie_name, $cookie_token, time() + (86400 * 7), "/");
        header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
        exit;
    } else {
        $login_error = "Kata sandi salah! Silakan coba lagi.";
    }
}

// C. Proses Logout / Kunci Dashboard
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    setcookie($cookie_name, "", time() - 3600, "/");
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}

// D. Pengecekan Status Login Saat Ini
$is_authenticated = (isset($_COOKIE[$cookie_name]) && $_COOKIE[$cookie_name] === $cookie_token);

// ==========================================
// 4. ENDPOINT DATA JSON & ROLLING TOKEN QR
// ==========================================
if (isset($_GET['action']) && $_GET['action'] === 'fetch_data') {
    header('Content-Type: application/json; charset=utf-8');
    
    if (!$is_authenticated) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Akses Ditolak"]);
        exit;
    }

    // Perhitungan Rolling Token Dinamis Saat Ini (30 Detik)
    $time_window     = floor(time() / 30);
    $active_qr_token = substr(hash('sha256', $time_window . $secret_token_qr), 0, 16);

    mysqli_report(MYSQLI_REPORT_OFF);
    $conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Koneksi gagal"]);
        exit;
    }
    $conn->query("SET time_zone = '+07:00'");

    $tipe         = isset($_GET['tipe']) ? $_GET['tipe'] : 'pkkmb';
    $hari_filter  = isset($_GET['hari']) ? trim($_GET['hari']) : '';
    $gugus_filter = isset($_GET['gugus']) ? trim($_GET['gugus']) : '';

    $tot_pkkmb = 0; $tot_pembekalan = 0; $tot_pelanggaran = 0;
    
    $r1 = $conn->query("SELECT COUNT(*) AS c FROM presensi_pkkmb");
    if ($r1) { $tot_pkkmb = (int)$r1->fetch_assoc()['c']; }
    
    $r2 = $conn->query("SELECT COUNT(*) AS c FROM presensi_pembekalan");
    if ($r2) { $tot_pembekalan = (int)$r2->fetch_assoc()['c']; }

    $r3 = $conn->query("SELECT COUNT(*) AS c FROM presensi_pelanggaran");
    if ($r3) { $tot_pelanggaran = (int)$r3->fetch_assoc()['c']; }

    $stat_hari = [];
    $res_hari = $conn->query("SELECT hari_kehadiran, COUNT(*) as jml FROM presensi_pkkmb GROUP BY hari_kehadiran");
    if ($res_hari) {
        while ($r = $res_hari->fetch_assoc()) {
            $stat_hari[$r['hari_kehadiran']] = (int)$r['jml'];
        }
    }

    $data = [];

    if ($tipe === 'pelanggaran') {
        $sql = "SELECT id, nama_lengkap, gugus_kelompok, hari_kehadiran, keterangan, waktu_percobaan FROM presensi_pelanggaran ORDER BY waktu_percobaan DESC, id DESC LIMIT 200";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $data[] = [
                    'id'              => $row['id'],
                    'nama_lengkap'    => htmlspecialchars($row['nama_lengkap']),
                    'gugus_kelompok'  => htmlspecialchars($row['gugus_kelompok']),
                    'hari_kehadiran'  => htmlspecialchars($row['hari_kehadiran']),
                    'keterangan'      => htmlspecialchars($row['keterangan']),
                    'waktu_percobaan' => date('d M Y - H:i:s', strtotime($row['waktu_percobaan']))
                ];
            }
        }
    } elseif ($tipe === 'pembekalan') {
        $sql = "SELECT id, nama_lengkap, waktu_absen FROM presensi_pembekalan ORDER BY id ASC";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $data[] = [
                    'id'           => $row['id'],
                    'nama_lengkap' => htmlspecialchars($row['nama_lengkap']),
                    'waktu_absen'  => date('d M Y - H:i:s', strtotime($row['waktu_absen']))
                ];
            }
        }
    } else {
        $sql = "SELECT id, nama_lengkap, gugus_kelompok, hari_kehadiran, waktu_absen FROM presensi_pkkmb WHERE 1=1";
        $params = [];
        $types = "";

        if (!empty($hari_filter)) {
            $sql .= " AND hari_kehadiran = ?";
            $params[] = $hari_filter;
            $types .= "s";
        }
        if (!empty($gugus_filter)) {
            $sql .= " AND gugus_kelompok = ?";
            $params[] = $gugus_filter;
            $types .= "s";
        }
        $sql .= " ORDER BY FIELD(hari_kehadiran, 'Hari Ke-1', 'Hari Ke-2', 'Hari Ke-3') ASC, CAST(SUBSTRING_INDEX(gugus_kelompok, ' ', -1) AS UNSIGNED) ASC, gugus_kelompok ASC, nama_lengkap ASC";

        $stmt = $conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $data[] = [
                'id'             => $row['id'],
                'nama_lengkap'   => htmlspecialchars($row['nama_lengkap']),
                'hari_kehadiran' => htmlspecialchars($row['hari_kehadiran']),
                'gugus_kelompok' => htmlspecialchars($row['gugus_kelompok']),
                'waktu_absen'    => date('d M Y - H:i:s', strtotime($row['waktu_absen']))
            ];
        }
        $stmt->close();
    }

    echo json_encode([
        "status"          => "success",
        "tipe"            => $tipe,
        "tot_pkkmb"       => $tot_pkkmb,
        "tot_pembekalan"  => $tot_pembekalan,
        "tot_pelanggaran" => $tot_pelanggaran,
        "stat_hari"       => $stat_hari,
        "active_qr_token" => $active_qr_token,
        "data"            => $data
    ]);

    $conn->close();
    exit;
}

// ==========================================
// VIEW 1: JIKA BELUM LOGIN (TAMPILKAN LAYAR KUNCI)
// ==========================================
if (!$is_authenticated):
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <title>Akses Terkunci - Live Monitor</title>
  <link rel="icon" type="image/jpeg" href="logodona.jpg">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>body { font-family: 'Plus Jakarta Sans', sans-serif; }</style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex items-center justify-center p-4">
  <div class="w-full max-w-sm bg-slate-900 border border-slate-800 p-6 md:p-8 rounded-3xl shadow-2xl text-center space-y-6">
    <div class="flex justify-center">
      <img src="logodona.jpg" alt="Logo STIKes Dona Palembang" class="h-16 md:h-20 w-auto object-contain rounded-xl bg-white p-1" onerror="this.style.display='none'">
    </div>
    <div>
      <h2 class="text-xl font-bold text-white tracking-tight">Akses Khusus Panitia</h2>
      <p class="text-xs text-slate-400 mt-1">Masukkan kata sandi untuk membuka live monitor</p>
    </div>

    <?php if (!empty($login_error)): ?>
    <div class="bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs py-2.5 px-3 rounded-xl">
      <?= htmlspecialchars($login_error) ?>
    </div>
    <?php endif; ?>

    <form method="POST" action="" class="space-y-4 text-left" autocomplete="off">
      <div>
        <label for="pin_akses" class="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Kata Sandi</label>
        <div class="relative">
          <input type="password" id="pin_akses" name="pin_akses" required placeholder="Masukkan kata sandi..." class="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 pr-11 transition">
          <button type="button" onclick="togglePass()" class="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-white transition focus:outline-none">
            <svg id="eyeOpen" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
            <svg id="eyeClose" class="w-5 h-5 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18"/></svg>
          </button>
        </div>
      </div>
      <button type="submit" class="w-full py-3 px-4 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl shadow-lg transition active:scale-[0.98]">
        Buka Dashboard
      </button>
    </form>
  </div>
  <script>
    window.addEventListener('pageshow', function(event) {
      if (event.persisted) {
        window.location.reload();
      }
    });

    function togglePass() {
      const input = document.getElementById('pin_akses');
      const open = document.getElementById('eyeOpen');
      const close = document.getElementById('eyeClose');
      if (input.type === 'password') {
        input.type = 'text'; open.classList.add('hidden'); close.classList.remove('hidden');
      } else {
        input.type = 'password'; open.classList.remove('hidden'); close.classList.add('hidden');
      }
    }
  </script>
</body>
</html>
<?php 
exit;
endif; 

// ==========================================
// VIEW 2: JIKA SUDAH LOGIN (TAMPILKAN DASHBOARD)
// ==========================================
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  <title>Live Monitoring Terpadu 2026</title>
  <link rel="icon" type="image/jpeg" href="logodona.jpg">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; }
    @keyframes pulse-fast { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.4; transform: scale(1.1); } }
    .live-dot { animation: pulse-fast 1.5s infinite; }
    #qrcodeContainer canvas, #qrcodeContainer img {
      width: 100% !important;
      height: auto !important;
      display: block;
      margin: 0 auto;
    }
  </style>
</head>
<body class="bg-slate-900 text-slate-100 min-h-screen p-3 sm:p-5 md:p-8">

  <div class="max-w-7xl mx-auto space-y-5 md:space-y-6">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-800/80 backdrop-blur border border-slate-700/60 p-4 md:p-5 rounded-2xl shadow-xl">
      <div class="flex items-center space-x-3 md:space-x-4">
        <img src="logodona.jpg" alt="Logo STIKes Dona Palembang" class="h-12 md:h-14 w-auto object-contain rounded-lg bg-white p-1" onerror="this.style.display='none'">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-base sm:text-lg md:text-2xl font-bold tracking-tight text-white">Live Monitor Presensi</h1>
            <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot"></span> LIVE
            </span>
          </div>
          <p class="text-[11px] sm:text-xs text-slate-400 mt-0.5">STIKes Dona Palembang • Pemantauan Real-Time</p>
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-2 sm:gap-3">
        <button onclick="openQrModal('pkkmb')" class="flex-1 sm:flex-none px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-xl transition shadow flex items-center justify-center gap-1.5">
          📱 QR PKKMB
        </button>

        <button onclick="openQrModal('pembekalan')" class="flex-1 sm:flex-none px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition shadow flex items-center justify-center gap-1.5">
          📖 QR Pembekalan
        </button>

        <div class="text-right hidden md:block bg-slate-900/60 border border-slate-700/80 px-3.5 py-1.5 rounded-xl">
          <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Waktu Sekarang</p>
          <p id="liveClock" class="text-sm font-mono font-bold text-emerald-400">--:--:-- WIB</p>
        </div>

        <button id="toggleAutoBtn" onclick="toggleAutoRefresh()" class="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-xl transition shadow">
          Auto (3s)
        </button>

        <button onclick="handleLogout()" class="px-3 py-2 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-bold rounded-xl transition shadow flex items-center gap-1">
          🔒 Kunci
        </button>
      </div>
    </div>

    <div class="flex flex-wrap gap-1.5 sm:gap-2 p-1.5 bg-slate-950/60 rounded-2xl border border-slate-800 w-full sm:w-fit">
      <button id="tabPKKMB" onclick="switchTipe('pkkmb')" class="flex-1 sm:flex-none px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-sm bg-sky-600 text-white text-center">
        🎓 PKKMB (3 Hari)
      </button>
      <button id="tabPembekalan" onclick="switchTipe('pembekalan')" class="flex-1 sm:flex-none px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition text-slate-400 hover:text-white text-center">
        📖 Pembekalan (1 Hari)
      </button>
      <button id="tabPelanggaran" onclick="switchTipe('pelanggaran')" class="w-full sm:w-auto px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition text-rose-400 hover:text-white flex items-center justify-center gap-1.5 text-center">
        ⚠️ Tidak Ikut Pembekalan <span id="badgePelanggaran" class="bg-rose-600 text-white px-1.5 py-0.2 rounded-full text-[10px]">0</span>
      </button>
    </div>

    <div id="statsContainerPKKMB" class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      <div class="bg-slate-800/80 border border-slate-700/60 p-3.5 sm:p-4 rounded-2xl shadow">
        <p class="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-slate-400">Total Hadir PKKMB</p>
        <div class="flex items-baseline justify-between mt-1 sm:mt-2">
          <span id="statTotal" class="text-2xl sm:text-3xl font-extrabold text-white">0</span>
          <span class="text-[11px] sm:text-xs text-slate-400">Peserta</span>
        </div>
      </div>
      <div class="bg-slate-800/80 border border-slate-700/60 p-3.5 sm:p-4 rounded-2xl shadow">
        <p class="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-sky-400">Hari Ke-1</p>
        <div class="flex items-baseline justify-between mt-1 sm:mt-2">
          <span id="statHari1" class="text-2xl sm:text-3xl font-extrabold text-sky-300">0</span>
          <span class="text-[11px] sm:text-xs text-slate-400">Peserta</span>
        </div>
      </div>
      <div class="bg-slate-800/80 border border-slate-700/60 p-3.5 sm:p-4 rounded-2xl shadow">
        <p class="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-amber-400">Hari Ke-2</p>
        <div class="flex items-baseline justify-between mt-1 sm:mt-2">
          <span id="statHari2" class="text-2xl sm:text-3xl font-extrabold text-amber-300">0</span>
          <span class="text-[11px] sm:text-xs text-slate-400">Peserta</span>
        </div>
      </div>
      <div class="bg-slate-800/80 border border-slate-700/60 p-3.5 sm:p-4 rounded-2xl shadow">
        <p class="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-violet-400">Hari Ke-3</p>
        <div class="flex items-baseline justify-between mt-1 sm:mt-2">
          <span id="statHari3" class="text-2xl sm:text-3xl font-extrabold text-violet-300">0</span>
          <span class="text-[11px] sm:text-xs text-slate-400">Peserta</span>
        </div>
      </div>
    </div>

    <div id="statsContainerPembekalan" class="hidden grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
      <div class="bg-slate-800/80 border border-slate-700/60 p-4 sm:p-5 rounded-2xl shadow">
        <p class="text-xs font-semibold uppercase tracking-wider text-emerald-400">Total Kehadiran Pembekalan</p>
        <div class="flex items-baseline justify-between mt-2">
          <span id="statPembekalanTotal" class="text-3xl sm:text-4xl font-extrabold text-white">0</span>
          <span class="text-xs text-slate-400">Mahasiswa Terdaftar</span>
        </div>
      </div>
    </div>

    <div id="statsContainerPelanggaran" class="hidden grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
      <div class="bg-slate-800/80 border border-rose-900/60 p-4 sm:p-5 rounded-2xl shadow">
        <p class="text-xs font-semibold uppercase tracking-wider text-rose-400">Total Percobaan Ilegal / Lewati Pembekalan</p>
        <div class="flex items-baseline justify-between mt-2">
          <span id="statPelanggaranTotal" class="text-3xl sm:text-4xl font-extrabold text-rose-400">0</span>
          <span class="text-xs text-slate-400">Percobaan Ditolak</span>
        </div>
      </div>
    </div>

    <div class="bg-slate-800/80 border border-slate-700/60 p-3.5 sm:p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow">
      <div class="flex flex-wrap items-center gap-2.5 sm:gap-3 w-full md:w-auto">
        <div class="relative w-full sm:w-64">
          <input type="text" id="searchInput" oninput="filterLocalData()" placeholder="Cari nama peserta..." class="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500">
        </div>

        <select id="filterHari" onchange="loadData()" class="flex-1 sm:flex-none bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500">
          <option value="">Semua Hari</option>
          <option value="Hari Ke-1">Hari Ke-1</option>
          <option value="Hari Ke-2">Hari Ke-2</option>
          <option value="Hari Ke-3">Hari Ke-3</option>
        </select>

        <select id="filterGugus" onchange="loadData()" class="flex-1 sm:flex-none bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500">
          <option value="">Semua Gugus</option>
          <?php for($i=1; $i<=10; $i++): ?>
            <option value="Gugus / Kelompok <?= $i ?>">Gugus / Kelompok <?= $i ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="text-xs text-slate-400 w-full sm:w-auto text-right">
        Menampilkan <span id="recordCount" class="font-bold text-white">0</span> entri
      </div>
    </div>

    <div class="bg-slate-800/80 border border-slate-700/60 rounded-2xl shadow-xl overflow-hidden">
      <div class="overflow-x-auto max-h-[600px] overflow-y-auto">
        <table class="w-full text-left text-xs border-collapse min-w-[500px]">
          <thead class="bg-slate-950/70 sticky top-0 backdrop-blur z-10 border-b border-slate-700" id="tableHeader">
          </thead>
          <tbody id="tableBody" class="divide-y divide-slate-700/60">
            <tr>
              <td colspan="5" class="py-8 text-center text-slate-500">Memuat data presensi...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <!-- MODAL QR CODE -->
  <div id="qrModal" class="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 hidden overflow-y-auto">
    <div class="bg-slate-900 border border-slate-700 p-4 sm:p-6 md:p-8 rounded-3xl max-w-sm sm:max-w-md w-full text-center space-y-4 shadow-2xl relative my-auto">
      <button onclick="closeQrModal()" class="absolute top-3 right-3 sm:top-4 sm:right-4 text-slate-400 hover:text-white text-lg font-bold p-1">✕</button>
      
      <div class="flex p-1 bg-slate-800 rounded-xl border border-slate-700 gap-1 mt-1">
        <button id="qrTabPkkmb" onclick="generateModalQr('pkkmb')" class="flex-1 py-2 text-[11px] sm:text-xs font-bold rounded-lg transition bg-sky-600 text-white">
          🎓 Presensi PKKMB
        </button>
        <button id="qrTabPembekalan" onclick="generateModalQr('pembekalan')" class="flex-1 py-2 text-[11px] sm:text-xs font-bold rounded-lg transition text-slate-400 hover:text-white">
          📖 Pembekalan
        </button>
      </div>

      <div>
        <h3 id="modalTitle" class="text-base sm:text-lg font-bold text-white tracking-tight">Kode QR Presensi PKKMB</h3>
        <p class="text-[11px] sm:text-xs text-slate-400 mt-0.5">Scan langsung melalui Kamera HP / Google Lens</p>
      </div>

      <div class="bg-white p-3 sm:p-4 rounded-2xl inline-flex items-center justify-center shadow-2xl mx-auto border-2 sm:border-4 border-slate-800 w-full max-w-[240px] sm:max-w-[280px] aspect-square">
        <div id="qrcodeContainer" class="w-full h-full flex items-center justify-center"></div>
      </div>

      <!-- Tombol Buka Link Langsung -->
      <a id="btnOpenLink" href="#" target="_blank" rel="noopener noreferrer" class="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition shadow flex items-center justify-center gap-1.5">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
        </svg>
        Buka Tautan Presensi
      </a>

      <div class="bg-slate-800/90 p-3 rounded-xl border border-slate-700 text-left flex items-center justify-between">
        <div class="min-w-0 pr-2">
          <p class="text-[9px] sm:text-[10px] text-slate-400 uppercase font-bold tracking-wider">Token Aktif:</p>
          <p id="activeQrTokenDisplay" class="text-xs sm:text-sm font-mono font-bold text-emerald-400 truncate">Memuat...</p>
        </div>
        <div class="text-right flex-shrink-0">
          <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/20 text-sky-400 border border-sky-500/30">
            🔄 30s
          </span>
        </div>
      </div>

      <p class="text-[10px] sm:text-xs text-slate-500 leading-tight">
        Kode QR & token berputar otomatis setiap 30 detik untuk mencegah tautan dibagikan.
      </p>
    </div>
  </div>

  <script>
    let currentTipe = 'pkkmb';
    let modalActiveType = 'pkkmb';
    let rawData = [];
    let isAutoRefresh = true;
    let refreshInterval = null;
    let activeQrToken = '';

    window.addEventListener('pageshow', function(event) {
      if (event.persisted) {
        window.location.reload();
      }
    });

    function handleLogout() {
      clearInterval(refreshInterval);
      window.location.replace('?action=logout');
    }

    function updateDigitalClock() {
      const now = new Date();
      const jam = String(now.getHours()).padStart(2, '0');
      const menit = String(now.getMinutes()).padStart(2, '0');
      const detik = String(now.getSeconds()).padStart(2, '0');
      const clockEl = document.getElementById('liveClock');
      if (clockEl) clockEl.innerText = `${jam}:${menit}:${detik} WIB`;
    }
    setInterval(updateDigitalClock, 1000);
    updateDigitalClock();

    async function loadData() {
      const hari = (currentTipe === 'pkkmb') ? document.getElementById('filterHari').value : '';
      const gugus = (currentTipe === 'pkkmb') ? document.getElementById('filterGugus').value : '';
      
      const url = `?action=fetch_data&tipe=${currentTipe}&hari=${encodeURIComponent(hari)}&gugus=${encodeURIComponent(gugus)}`;

      try {
        const res = await fetch(url);
        const json = await res.json();

        if (json.status === 'success') {
          rawData = json.data;

          document.getElementById('badgePelanggaran').innerText = json.tot_pelanggaran;

          if (currentTipe === 'pkkmb') {
            document.getElementById('statTotal').innerText = json.tot_pkkmb;
            document.getElementById('statHari1').innerText = json.stat_hari['Hari Ke-1'] || 0;
            document.getElementById('statHari2').innerText = json.stat_hari['Hari Ke-2'] || 0;
            document.getElementById('statHari3').innerText = json.stat_hari['Hari Ke-3'] || 0;
          } else if (currentTipe === 'pembekalan') {
            document.getElementById('statPembekalanTotal').innerText = json.tot_pembekalan;
          } else {
            document.getElementById('statPelanggaranTotal').innerText = json.tot_pelanggaran;
          }

          // Sinkronisasi Rolling QR Token
          if (json.active_qr_token && json.active_qr_token !== activeQrToken) {
            activeQrToken = json.active_qr_token;
            document.getElementById('activeQrTokenDisplay').innerText = activeQrToken;
            
            const qrModalElem = document.getElementById('qrModal');
            if (!qrModalElem.classList.contains('hidden')) {
              renderQrCode();
            }
          }

          filterLocalData();
        } else if (res.status === 403) {
          handleLogout();
        }
      } catch (err) {}
    }

    function filterLocalData() {
      const search = document.getElementById('searchInput').value.toLowerCase().trim();
      const filtered = rawData.filter(item => item.nama_lengkap.toLowerCase().includes(search));

      document.getElementById('recordCount').innerText = filtered.length;

      const thead = document.getElementById('tableHeader');
      const tbody = document.getElementById('tableBody');

      if (currentTipe === 'pelanggaran') {
        thead.innerHTML = `
          <tr>
            <th class="py-3.5 px-4 font-bold text-rose-400 uppercase">Status Pelanggaran</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Nama Terduga</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Gugus Dicoba</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Hari Dicoba</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Waktu Percobaan</th>
          </tr>
        `;
      } else if (currentTipe === 'pembekalan') {
        thead.innerHTML = `
          <tr>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">No. ID</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Nama Lengkap Mahasiswa</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Status</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Waktu Absen (WIB)</th>
          </tr>
        `;
      } else {
        thead.innerHTML = `
          <tr>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Presensi</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Gugus / Kelompok</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Nama Lengkap</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">No. ID</th>
            <th class="py-3.5 px-4 font-bold text-slate-400 uppercase">Waktu Absen (WIB)</th>
          </tr>
        `;
      }

      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="py-8 text-center text-slate-500">Belum ada data yang sesuai.</td></tr>`;
        return;
      }

      if (currentTipe === 'pelanggaran') {
        tbody.innerHTML = filtered.map((row) => `
          <tr class="hover:bg-rose-950/20 transition bg-rose-950/10">
            <td class="py-3 px-4">
              <span class="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center gap-1 w-fit">
                ⛔ Lewati Pembekalan
              </span>
            </td>
            <td class="py-3 px-4 font-bold text-rose-300">${row.nama_lengkap}</td>
            <td class="py-3 px-4 text-slate-400">${row.gugus_kelompok || '-'}</td>
            <td class="py-3 px-4 font-mono text-slate-300">${row.hari_kehadiran}</td>
            <td class="py-3 px-4 font-mono text-rose-400/80">${row.waktu_percobaan}</td>
          </tr>
        `).join('');
      } else if (currentTipe === 'pembekalan') {
        tbody.innerHTML = filtered.map((row) => `
          <tr class="hover:bg-slate-700/40 transition">
            <td class="py-3 px-4 font-mono font-bold text-emerald-400">#${row.id}</td>
            <td class="py-3 px-4 font-semibold text-slate-100">${row.nama_lengkap}</td>
            <td class="py-3 px-4">
              <span class="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Terdaftar
              </span>
            </td>
            <td class="py-3 px-4 font-mono text-slate-400">${row.waktu_absen}</td>
          </tr>
        `).join('');
      } else {
        tbody.innerHTML = filtered.map((row) => `
          <tr class="hover:bg-slate-700/40 transition">
            <td class="py-3 px-4">
              <span class="px-2.5 py-1 rounded-lg text-[11px] font-semibold ${
                row.hari_kehadiran === 'Hari Ke-1' ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' :
                row.hari_kehadiran === 'Hari Ke-2' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                'bg-violet-500/20 text-violet-300 border border-violet-500/30'
              }">
                ${row.hari_kehadiran}
              </span>
            </td>
            <td class="py-3 px-4">
              <span class="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-slate-900 text-slate-300 border border-slate-700">
                ${row.gugus_kelompok}
              </span>
            </td>
            <td class="py-3 px-4 font-semibold text-slate-100">${row.nama_lengkap}</td>
            <td class="py-3 px-4 font-mono font-bold text-sky-400">#${row.id}</td>
            <td class="py-3 px-4 font-mono text-slate-400">${row.waktu_absen}</td>
          </tr>
        `).join('');
      }
    }

    function openQrModal(type = 'pkkmb') {
      const modal = document.getElementById('qrModal');
      generateModalQr(type);
      modal.classList.remove('hidden');
    }

    function generateModalQr(type) {
      modalActiveType = type;
      const tabP = document.getElementById('qrTabPkkmb');
      const tabB = document.getElementById('qrTabPembekalan');
      const title = document.getElementById('modalTitle');

      if (type === 'pembekalan') {
        title.innerText = 'Kode QR Presensi Pembekalan';
        tabB.className = 'flex-1 py-2 text-[11px] sm:text-xs font-bold rounded-lg transition bg-emerald-600 text-white';
        tabP.className = 'flex-1 py-2 text-[11px] sm:text-xs font-bold rounded-lg transition text-slate-400 hover:text-white';
      } else {
        title.innerText = 'Kode QR Presensi PKKMB';
        tabP.className = 'flex-1 py-2 text-[11px] sm:text-xs font-bold rounded-lg transition bg-sky-600 text-white';
        tabB.className = 'flex-1 py-2 text-[11px] sm:text-xs font-bold rounded-lg transition text-slate-400 hover:text-white';
      }

      renderQrCode();
    }

    // RENDER QR CODE & UPDATE TOMBOL LINK
    function renderQrCode() {
      const container = document.getElementById('qrcodeContainer');
      container.innerHTML = '';

      if (!activeQrToken) return;

      let targetUrl = '';
      if (modalActiveType === 'pembekalan') {
        targetUrl = `https://4bsensipkkmb.gt.tc/absenpembekalan?token=${activeQrToken}`;
      } else {
        targetUrl = `https://4bsensipkkmb.gt.tc/?token=${activeQrToken}`;
      }

      new QRCode(container, {
        text: targetUrl,
        width: 300,
        height: 300,
        colorDark: "#0f172a",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.M
      });

      // Update URL dan warna tombol Buka Link secara dinamis
      const btnLink = document.getElementById('btnOpenLink');
      if (btnLink) {
        btnLink.href = targetUrl;
        if (modalActiveType === 'pembekalan') {
          btnLink.className = 'w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition shadow flex items-center justify-center gap-1.5';
        } else {
          btnLink.className = 'w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition shadow flex items-center justify-center gap-1.5';
        }
      }
    }

    function closeQrModal() {
      document.getElementById('qrModal').classList.add('hidden');
    }

    function switchTipe(tipe) {
      currentTipe = tipe;
      const tabPKKMB = document.getElementById('tabPKKMB');
      const tabPembekalan = document.getElementById('tabPembekalan');
      const tabPelanggaran = document.getElementById('tabPelanggaran');
      
      const statsPKKMB = document.getElementById('statsContainerPKKMB');
      const statsPembekalan = document.getElementById('statsContainerPembekalan');
      const statsPelanggaran = document.getElementById('statsContainerPelanggaran');

      const filterHari = document.getElementById('filterHari');
      const filterGugus = document.getElementById('filterGugus');

      tabPKKMB.className = 'flex-1 sm:flex-none px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition text-slate-400 hover:text-white text-center';
      tabPembekalan.className = 'flex-1 sm:flex-none px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition text-slate-400 hover:text-white text-center';
      tabPelanggaran.className = 'w-full sm:w-auto px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition text-rose-400 hover:text-white flex items-center justify-center gap-1.5 text-center';

      statsPKKMB.classList.add('hidden');
      statsPembekalan.classList.add('hidden');
      statsPelanggaran.classList.add('hidden');

      if (tipe === 'pelanggaran') {
        tabPelanggaran.className = 'w-full sm:w-auto px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-sm bg-rose-600 text-white flex items-center justify-center gap-1.5 text-center';
        statsPelanggaran.classList.remove('hidden');
        filterHari.classList.add('hidden');
        filterGugus.classList.add('hidden');
      } else if (tipe === 'pembekalan') {
        tabPembekalan.className = 'flex-1 sm:flex-none px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-sm bg-emerald-600 text-white text-center';
        statsPembekalan.classList.remove('hidden');
        filterHari.classList.add('hidden');
        filterGugus.classList.add('hidden');
      } else {
        tabPKKMB.className = 'flex-1 sm:flex-none px-3 sm:px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-sm bg-sky-600 text-white text-center';
        statsPKKMB.classList.remove('hidden');
        filterHari.classList.remove('hidden');
        filterGugus.classList.remove('hidden');
      }

      loadData();
    }

    function toggleAutoRefresh() {
      const btn = document.getElementById('toggleAutoBtn');
      if (isAutoRefresh) {
        clearInterval(refreshInterval);
        isAutoRefresh = false;
        btn.innerText = 'Auto: OFF';
        btn.className = 'px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl transition shadow';
      } else {
        isAutoRefresh = true;
        btn.innerText = 'Auto (3s)';
        btn.className = 'px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-xl transition shadow';
        startInterval();
        loadData();
      }
    }

    function startInterval() {
      refreshInterval = setInterval(loadData, 3000);
    }

    loadData();
    startInterval();
  </script>
</body>
</html>
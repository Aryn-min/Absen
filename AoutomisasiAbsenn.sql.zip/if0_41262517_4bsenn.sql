-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql304.infinityfree.com
-- Generation Time: Aug 18, 2026 at 08:45 AM
-- Server version: 11.4.12-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_41262517_4bsenn`
--

-- --------------------------------------------------------

--
-- Table structure for table `presensi_pelanggaran`
--

CREATE TABLE `presensi_pelanggaran` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `gugus_kelompok` varchar(50) NOT NULL,
  `hari_kehadiran` varchar(20) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `waktu_percobaan` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `presensi_pembekalan`
--

CREATE TABLE `presensi_pembekalan` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `hari_kehadiran` varchar(20) NOT NULL,
  `waktu_absen` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `presensi_pkkmb`
--

CREATE TABLE `presensi_pkkmb` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `gugus_kelompok` varchar(100) NOT NULL,
  `hari_kehadiran` varchar(50) NOT NULL,
  `waktu_absen` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `presensi_pelanggaran`
--
ALTER TABLE `presensi_pelanggaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `presensi_pembekalan`
--
ALTER TABLE `presensi_pembekalan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `presensi_pkkmb`
--
ALTER TABLE `presensi_pkkmb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `presensi_pelanggaran`
--
ALTER TABLE `presensi_pelanggaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `presensi_pembekalan`
--
ALTER TABLE `presensi_pembekalan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `presensi_pkkmb`
--
ALTER TABLE `presensi_pkkmb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
